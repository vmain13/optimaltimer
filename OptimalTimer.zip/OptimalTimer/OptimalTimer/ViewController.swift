//
//  ViewController.swift
//  OptimalTimer
//
//  Created by SOM Media Center on 12/8/17.
//  Copyright © 2017 Beatio LLC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var timerLabel: UILabel!
    @IBOutlet weak var restLabel: UILabel!
    @IBOutlet weak var pauseButton: UIButton!
    
    var seconds = 20
    var rest = 10
    
    var timer = Timer()
    var timer2 = Timer()
    var workOn = false
    var restOn = false
    // has the pause button been tapped
    var resumeTapped = false
    
    
    //MARK: - IBactions
    @IBAction func startButtonTapped(_ sender: Any) {
        if workOn == false {
            runTimer()
        }
    }
    
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target:self, selector: (#selector(ViewController.updateTimer)), userInfo: nil, repeats: true)
        workOn = true
        pauseButton.isEnabled = true
    }
    func restTimer(){
        timer2 = Timer.scheduledTimer(timeInterval: 1, target:self, selector: (#selector(ViewController.updaterestTimer)), userInfo: nil, repeats: true)
        restOn = true
    }
//work
    @objc func updateTimer() {
        //we are now in the work phase
        workOn = true
        rest = 10
        if seconds < 1 {
            timer.invalidate()
            restTimer()
        } else {
            seconds -= 1
            timerLabel.text = timeString(time:TimeInterval(seconds))
        }
    }
//Rest
    @objc func updaterestTimer() {
        seconds = 20
        if rest < 1 {
            timer2.invalidate()
            runTimer()
        } else {
            rest -= 1
            restLabel.text =
                timeString(time:TimeInterval(rest))
        }
    }
    @IBAction func pauseButtonTapped(_ sender: Any) {
        // the first time the pause button is tapped resumeTapped will be false
        if self.resumeTapped == false {
            // stop timer without resetting the current value of seconds
            timer.invalidate()
            timer2.invalidate()
            self.resumeTapped = true
            self.pauseButton.setTitle("Resume", for: .normal)
        } else {
            runTimer()
            restTimer()
            self.resumeTapped = false
            self.pauseButton.setTitle("Pause", for: .normal)
        }
    }
    
    @IBAction func resetButtonTapped(_ sender: Any) {
        timer.invalidate()
        timerLabel.text = timeString(time:TimeInterval(seconds))
        workOn = false
        // for rest
        timer2.invalidate()
        restLabel.text = timeString(time:TimeInterval(rest))
        // pause button should not be enabled
        pauseButton.isEnabled = false
    }
    
    func timeString(time:TimeInterval) -> String{
        let minutes = Int(time)/60 % 60
        let seconds = Int(time)%60
        return String(format:"%02i:%02i",minutes, seconds)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        pauseButton.isEnabled = false
        timerLabel.text = timeString(time:TimeInterval(0))
        restLabel.text = timeString(time:TimeInterval(0))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

